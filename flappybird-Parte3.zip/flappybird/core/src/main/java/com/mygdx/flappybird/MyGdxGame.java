package com.mygdx.flappybird;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.Random;

public class MyGdxGame extends ApplicationAdapter {
    SpriteBatch batch;
    Texture background;
    Texture[] birds;
    Texture topTube, bottomTube;
    int flapState = 0;
    float birdY;
    float velocity = 0;
    float gameState = 0;
    float gap = 500;
    Random random;
    int totalTubes = 5;
    float[] tubeX = new float[totalTubes];
    float[] tubeOffset = new float[totalTubes];
    float distanceBetweenTubes;
    float tubeVelocity = 4;

    @Override
    public void create() {
        batch = new SpriteBatch();
        background = new Texture("background.png");
        birds = new Texture[2];
        birds[0] = new Texture("flappybirdup.png");
        birds[1] = new Texture("flappybirddown.png");
        birdY = Gdx.graphics.getHeight() / 2 - birds[flapState].getHeight() / 2;
        topTube = new Texture("toptube.png");
        bottomTube = new Texture("bottomtube.png");

        random = new Random();
        distanceBetweenTubes = Gdx.graphics.getWidth() / 2;

        for (int i = 0; i < totalTubes; i++) {
            tubeX[i] = Gdx.graphics.getWidth() + i * distanceBetweenTubes;
            tubeOffset[i] = (random.nextFloat() - 0.5f) * (Gdx.graphics.getHeight() - gap - 200);
        }
    }

    @Override
    public void render() {
        batch.begin();
        batch.draw(background, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());

        if (gameState != 0) {
            if (Gdx.input.justTouched()) {
                velocity = -30;
            }

            for (int i = 0; i < totalTubes; i++) {
                if (tubeX[i] < -topTube.getWidth()) {
                    tubeX[i] += totalTubes * distanceBetweenTubes;
                    tubeOffset[i] = (random.nextFloat() - 0.5f) * (Gdx.graphics.getHeight() - gap - 200);
                } else {
                    tubeX[i] -= tubeVelocity;
                }

                batch.draw(topTube, tubeX[i], Gdx.graphics.getHeight() / 2 + gap / 2 + tubeOffset[i]);
                batch.draw(bottomTube, tubeX[i], Gdx.graphics.getHeight() / 2 - gap / 2 - bottomTube.getHeight() + tubeOffset[i]);
            }

            if (birdY > 0 || velocity < 0) {
                velocity += 2;
                birdY -= velocity;
            }
        } else {
            if (Gdx.input.justTouched()) {
                gameState = 1;
            }
        }

        flapState = flapState == 0 ? 1 : 0;
        batch.draw(birds[flapState], Gdx.graphics.getWidth() / 2 - birds[flapState].getWidth() / 2, birdY);
        batch.end();
    }

    @Override
    public void dispose() {
        batch.dispose();
        background.dispose();
        birds[0].dispose();
        birds[1].dispose();
        topTube.dispose();
        bottomTube.dispose();
    }
}

